export default {
    "appKey":"f9dbdaf8473a4039ac7226c2180ce5f1",
    "mapId":2047,
    "zoom":300,
    "zoomMax":400,
    "zomMin":100   
}